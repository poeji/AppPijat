###TODO list before 0.2 version###

- Support both: chaining and legacy "searcher" object
- Cover with tests for all major version of jQuery since 1.4.2
- Cover with tests all method of plugin (PhantomJS?)
- Review gulp-concat issue