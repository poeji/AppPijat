test("Setup for integrations test is ready, but what should we test, what is missed by Jasmine?..", function(){
    ok(true);
});